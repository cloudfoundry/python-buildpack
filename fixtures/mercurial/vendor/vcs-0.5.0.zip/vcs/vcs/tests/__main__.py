from __init__ import *

if __name__ == '__main__':
    main()
