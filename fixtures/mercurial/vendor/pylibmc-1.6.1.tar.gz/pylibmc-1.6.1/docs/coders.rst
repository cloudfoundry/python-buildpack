The List of Honored People
==========================

* Marc Abramowitz <marc@marc-abramowitz.com>
* Anton Baklanov <antonbaklanov@gmail.com>
* Johan Bergström <bugs@bergstroem.nu>
* Nikola Borisov <nikola.borisof@gmail.com>
* Rick Branson <rick@diodeware.com>
* Otto Bretz <otto.bretz@gmail.com>
* Misha Brukman <mbrukman@google.com>
* James Brown <jbrown@yelp.com>
* Adam Chainz <adam@adamj.eu>
* Mika Eloranta <mel@ohmu.fi>
* Ludvig Ericson <ludvig@lericson.se>
* Harvey Falcic <harvey.falcic@gmail.com>
* Michael Fladischer <FladischerMichael@fladi.at>
* Marius Gedminas <marius@gedmin.as>
* Joe Hansche <jhansche@myyearbook.com>
* Keli Hlodversson <keli@hapti.co>
* ketralnis <ketralnis@reddit.com>
* Paweł Kowalak <pawel.kowalak@gmail.com>
* Hiroki Kumzaki <hiroki.kumazaki@gmail.com>
* Patrick Lewis <patrick.lewis@eventure.com>
* Shivaram Lingamneni <slingamn@cs.stanford.edu>
* Andrew McFague <amcfague@wgen.net>
* Remoun Metyas <remoun.metyas@gmail.com>
* Ed Morley <emorley@mozilla.com>
* Rudá Moura <ruda.moura@gmail.com>
* Muneyuki Noguchi <nogu.dev@gmail.com>
* Sergey Pashinin <sergey@pashinin.com>
* Michael Schurter <schmichael@urbanairship.com>
* Radek Senfeld <rush@logic.cz>
* Noah Silas <noah@mahalo.com>
* Jari Sukanen <jari.sukanen@f-secure.com>
* John Watson <johnw@mahalo.com>
* John Whitlock <john-whitlock@ieee.org>
* Neil Williams <neil@reddit.com>
* Josh Wright <jshwright@gmail.com>
* Kelly Wong <kelly@bluejeans.com>

Thanks to `Blogg Esse AB`__ and `Send a Patch Jonken AB`__ for their support in
this open-source adventure, without these two companies this wouldn't have
happened.

__ http://blogg.se/
__ http://sendapatch.se/
